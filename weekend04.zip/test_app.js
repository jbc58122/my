var http = require('http');
var express = require('express');
var fs = require('fs');
var ejs = require('ejs');
var app = express();
var router = express.Router();

app.set('port', process.env.PORT || 3000);


router.route('/test').get(function(req,res) {
    console.log('test ejs...');
    
    fs.readFile('views/test.ejs', 'utf8', function(err, data) {
        res.writeHead(200, {'Content-Type':'text/html'});
        res.end(ejs.render(data, {'user':'Hong-gildong'}));
    });
    
});

app.use('/', router);

var server = http.createServer(app);
server.listen(app.get('port'), function() {
    console.log("http://localhost:%d", app.get('port'));
});