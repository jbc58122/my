//login.html에서 받은 정보를 ejs파일로 데이터를 전송하고 test2.ejs 파일에서 결과가 보여지도록 한다.

var http = require('http');
var express = require('express');
var fs = require('fs');
var ejs = require('ejs');
var app = express();
var router = express.Router();

app.set('port', process.env.PORT || 3001 );

router.route('/test2').get(function(res,req) {
    console.log('test2 ejs...');
    
    var id = req.query.id;
    var password = req.query.password;
    var loginData = {id:id, password:password};
    
    fs.readFile('views/test2.ejs', 'utf8', function(err, data) {
        res.writeHead(200, {'Content-Type':'text/html'});
        res.end(ejs.render(data,{'logindata':login.data}));
    })
    
});

app.use('/' , router);

var server = http.createServer(app);
server.listen(app.get('port'), function() {
    console.log("http://localhost:%d", app.get('port'));
});