var http = require('http');
var express = require('express');
var app = express();
var fs = require('fs');
var path = require('path');
var util = require('util');
var router = express.Router();
var static = require('serve-static');

var mongoose = require('mongoose');

app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
console.log('뷰엔진이 ejs로 설정 됨.');


app.use('/public', static(path.join(__dirname, 'public')));


//데이터베이스 연결
var database;
var UserSchema;
var UserModel;

function connectDB() {
    var dbUrl = "mongodb://localhost:27017/local";
    
    mongoose.Promise = global.Promise;
    mongoose.connect(dbUrl);
    database = mongoose.connection;
    
    database.on('error', console.error.bind(console, 'mongoose error.'));
    database.on('open', function() {
        console.log('데이터베이스에 연결 되었습니다. :%s', dbUrl);
        
        //user 스키마 및 모델 생성
        createUserSchema();
    });
    
    database.on('disconnected', function() {
        setTimeout(connectDB, 5000);
    });
}

function createUserSchema() {
    UserSchema = mongoose.Schema({
        id: String,
        password: String,
        name: String
    });
    
    UserSchema.static('findAll', function(callback) {
        return this.find({}, callback);
    });
    
    //UserModel 모델 정의
    UserModel = mongoose.model('users', UserSchema);
}

router.route('/users/list').get(function(req, res) {
    console.log('/users/list의 리스트 호출');
    if(database) {
        UserModel.findAll( function(err, results) {
            if(err) {
                console.log('사용자 리스트 에러 발생');
                return;
            }
            
            if(results) {
                //console.dir(results);
                var docs = [];
                for(i in results) {
                    docs.push(results[i]);
                }
                //console.log(docs);
                app.render('test4', {'userDocs':docs}, function(err, html) {
                    if(err) {
                        console.log("뷰 렌더링 중 오류 발생")
                        return;
                    } 
                    res.end(html);
                });
            } else {
                console.log('사용자 조회 실패!');
            }
        });
    }
});

//라우터 미들웨어 등록
app.use('/', router);

var server = http.createServer(app);
server.listen(app.get('port'), function() {
    console.log('http://localhsot:%d', app.get('port'));
    connectDB();
});